jQuery(document).ready(function() {
	$('.data').mask('00/00/0000');
	$('.tempo').mask('00:00');
	$('.data_tempo').mask('00/00/0000 00:00:00');
	$('.cep').mask('00000-000');
	$('.tel').mask('00000-0000');
	$('.ddd_tel').mask('(00) 000000000');
	$('.cpf').mask('000.000.000-00');
	$('.cnpj').mask('00.000.000/0000-00');
	// $('.lista-menu-mobile').hide();
});

$('.owl-carousel').owlCarousel({
    margin:10,
    loop:true,
    autoWidth:true,
    video:true,
    items:1,
    navigation : true,
    navigationText : ['<span class="fa-stack"><i class="fa fa-circle fa-stack-1x"></i><i class="fa fa-chevron-circle-left fa-stack-1x fa-inverse"></i></span>','<span class="fa-stack"><i class="fa fa-circle fa-stack-1x"></i><i class="fa fa-chevron-circle-right fa-stack-1x fa-inverse"></i></span>'],
})



$('#menu-mobile').click(function(){
	$('.lista-menu-mobile').css('display', 'block');
});
